let count = 0;
        function addToCart() {
            count++;
            document.getElementById('cart-count').innerText = `🛒 (${count})`;
            alert('Produk berhasil ditambahkan ke keranjang!');
        }

        // Efek transisi smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });